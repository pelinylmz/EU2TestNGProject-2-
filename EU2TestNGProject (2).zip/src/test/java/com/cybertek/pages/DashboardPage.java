package com.cybertek.pages;


public class DashboardPage extends BasePage {

    //no need to explicitly write constructor, because it will use its parents constructor.

}
